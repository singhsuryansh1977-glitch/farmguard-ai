
from pathlib import Path
from datetime import datetime
import math, textwrap, tempfile, subprocess, wave, struct
from PIL import Image, ImageDraw, ImageFont
import imageio_ffmpeg
try:
    from gtts import gTTS
except Exception:
    gTTS=None

BASE=Path(__file__).resolve().parent.parent
OUT=BASE/"generated_videos"; OUT.mkdir(parents=True,exist_ok=True)
W,H,FPS=1280,720,24
GREEN=(19,59,26);DEEP=(10,34,16);MINT=(225,241,226);WHITE=(250,252,248);TEXT=(18,49,23);MUTED=(87,105,91);GOLD=(210,164,49);RED=(179,59,50);ORANGE=(180,107,20);BLUE=(47,109,154)
def ft(n,b=False):
    c=["C:/Windows/Fonts/seguisb.ttf" if b else "C:/Windows/Fonts/segoeui.ttf","C:/Windows/Fonts/arialbd.ttf" if b else "C:/Windows/Fonts/arial.ttf","/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if b else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"]
    for p in c:
        if Path(p).exists(): return ImageFont.truetype(p,n)
    return ImageFont.load_default()
def wrap(s,n): return textwrap.wrap(str(s),width=n,break_long_words=False)
def bg():
    im=Image.new("RGB",(W,H)); px=im.load()
    for y in range(H):
        t=y/(H-1); c=tuple(int(DEEP[i]*(1-t)+GREEN[i]*t) for i in range(3))
        for x in range(W): px[x,y]=c
    return im
def header(d,dark=False):
    c=WHITE if dark else GREEN
    d.text((62,40),"FARMGUARD AI",font=ft(28,True),fill=c)
    d.text((62,75),"AI-powered farm decision report",font=ft(17),fill=(220,235,222) if dark else MUTED)
def card(d,xy,r,fill): d.rounded_rectangle(xy,radius=r,fill=fill)
def scene(title,subtitle):
    im=Image.new("RGB",(W,H),WHITE); d=ImageDraw.Draw(im); header(d)
    d.text((70,135),title,font=ft(48,True),fill=TEXT)
    if subtitle: d.text((72,195),subtitle,font=ft(23),fill=MUTED)
    return im,d
def footer(d,p,label):
    d.rounded_rectangle((70,665,1210,681),8,fill=(215,225,216)); d.rounded_rectangle((70,665,70+1140*p,681),8,fill=GREEN)
    d.text((70,630),label,font=ft(17,True),fill=MUTED)
def scenes(r):
    out=[]
    im=bg();d=ImageDraw.Draw(im);header(d,True);d.text((70,170),"WEEKLY FARM REPORT",font=ft(60,True),fill=WHITE);d.text((72,260),f"{r.get('crop','Rice')} farm",font=ft(36),fill=(223,240,225));d.text((72,315),f"Generated {datetime.now():%d %b %Y}",font=ft(21),fill=(203,225,205))
    card(d,(760,165,1170,470),30,(244,248,243));d.text((800,215),"FARM STATUS",font=ft(20,True),fill=GREEN);d.text((800,265),f"{r.get('crop_age',60)} days",font=ft(48,True),fill=TEXT);d.text((800,330),"Crop age",font=ft(18),fill=MUTED);d.text((800,375),f"{r.get('harvest_readiness',65)}%",font=ft(40,True),fill=TEXT);d.text((800,430),"Harvest readiness",font=ft(18),fill=MUTED);footer(d,.12,"01  FARM OVERVIEW");out.append(im)
    im,d=scene("Weather outlook","What the next 7 days mean for this farm");w=r["weather"];c=w["current"];dy=w["daily"]
    vals=[("TEMPERATURE",f"{round(c['temperature_2m'])}°C"),("HUMIDITY",f"{round(c['relative_humidity_2m'])}%"),("RAIN TODAY",f"{round(dy['precipitation_probability_max'][0])}%"),("7-DAY RAIN",f"{sum(dy['precipitation_sum']):.1f} mm")]
    for i,(a,b) in enumerate(vals):
        x=70+i*285;card(d,(x,275,x+255,445),24,MINT);d.text((x+22,305),a,font=ft(17,True),fill=MUTED);d.text((x+22,350),b,font=ft(38,True),fill=GREEN)
    msg="High rainfall expected — avoid unnecessary irrigation today." if float(dy["precipitation_probability_max"][0])>=70 else "Rain is limited — check field moisture before irrigation."
    card(d,(70,490,1210,610),24,(248,243,223));d.text((100,515),"WEATHER CONCLUSION",font=ft(18,True),fill=ORANGE)
    for i,line in enumerate(wrap(msg,68)[:2]): d.text((100,555+i*30),line,font=ft(23,True),fill=TEXT)
    footer(d,.28,"02  WEATHER");out.append(im)
    im,d=scene("Crop health","AI image analysis + environmental risk signals");p=r["prediction"];rk=r["disease_risk"];card(d,(70,270,790,570),26,(244,248,243));d.text((105,305),"AI DIAGNOSIS",font=ft(18,True),fill=MUTED);d.text((105,355),p["disease"],font=ft(37,True),fill=GREEN if p["confidence"] else ORANGE);d.text((105,420),f"Confidence: {p['confidence']}%",font=ft(25),fill=TEXT);rc=RED if rk["level"]=="HIGH" else ORANGE if rk["level"]=="MODERATE" else GREEN;d.text((105,470),f"Overall risk: {rk['level']} ({rk['score']}/100)",font=ft(24,True),fill=rc);card(d,(830,270,1210,570),26,(251,242,240) if rk["level"]=="HIGH" else (248,243,223));d.text((860,310),"ACTION",font=ft(18,True),fill=MUTED);yy=360
    for line in wrap(rk["advice"],28)[:6]: d.text((860,yy),line,font=ft(19),fill=TEXT);yy+=29
    footer(d,.46,"03  CROP HEALTH");out.append(im)
    im,d=scene("Water management","A decision based on rain, ET₀ and field conditions");x=r["irrigation"][0];act=x["action"];color=GREEN if "NO" in act or "CHECK" in act else BLUE;card(d,(70,275,1210,520),28,MINT);d.text((105,320),act,font=ft(43,True),fill=color);yy=395
    for line in wrap(x["reason"],68)[:3]: d.text((105,yy),line,font=ft(24),fill=TEXT);yy+=33
    d.text((105,470),"Decision support: reduce avoidable pumping while protecting the crop.",font=ft(20),fill=MUTED);footer(d,.62,"04  WATER");out.append(im)
    im,d=scene("Market intelligence","An estimated trend, not a guaranteed future price");m=r["market"];card(d,(70,275,560,540),28,MINT);d.text((105,315),"CURRENT",font=ft(17,True),fill=MUTED);d.text((105,355),f"₹{m['current']:,.0f}",font=ft(56,True),fill=GREEN);d.text((105,430),"per quintal",font=ft(21),fill=MUTED);card(d,(620,275,1210,540),28,(244,248,243));d.text((660,315),"EXPECTED RANGE",font=ft(17,True),fill=MUTED);d.text((660,360),f"₹{m['expected_low']:,.0f} – ₹{m['expected_high']:,.0f}",font=ft(36,True),fill=TEXT);d.text((660,435),f"Trend: {m['trend']}",font=ft(24,True),fill=GREEN if m["trend"]=="UP" else ORANGE);footer(d,.78,"05  MARKET");out.append(im)
    im,d=scene("Your next 7 days","The most important actions, in priority order")
    for i,x in enumerate(r["plan"][:7]):
        col=i%4;row=i//4;xx=65+col*300;yy=250+row*205;card(d,(xx,yy,xx+270,yy+190),20,(244,248,243));d.text((xx+15,yy+14),f"DAY {x['day']}",font=ft(16,True),fill=MUTED)
        for j,line in enumerate(wrap(x["action"],20)[:2]): d.text((xx+15,yy+50+j*25),line,font=ft(19,True),fill=GREEN)
        rr=wrap(x["reason"],26)[0] if x["reason"] else "";d.text((xx+15,yy+118),rr,font=ft(15),fill=MUTED)
    footer(d,.92,"06  ACTION PLAN");out.append(im)
    im=bg();d=ImageDraw.Draw(im);header(d,True);d.text((70,165),"FARMGUARD RECOMMENDATION",font=ft(46,True),fill=WHITE);lines=[f"Today: {r['plan'][0]['action']}",f"Crop risk: {r['disease_risk']['level']}",f"Market trend: {r['market']['trend']}","Reassess as new field observations and weather arrive."]
    yy=275
    for i,line in enumerate(lines): d.text((90,yy),line,font=ft(30,i<3),fill=WHITE if i==0 else (226,240,227));yy+=58
    d.text((90,575),"Protect the crop. Plan the action. Protect farm income.",font=ft(25,True),fill=GOLD);footer(d,1.0,"07  FINAL RECOMMENDATION");out.append(im)
    return out

def make_bg_audio(p,seconds):
    rate=22050
    with wave.open(str(p),"w") as w:
        w.setnchannels(1);w.setsampwidth(2);w.setframerate(rate)
        for i in range(int(seconds*rate)):
            t=i/rate;fade=min(1,t/.7,(seconds-t)/.7);v=int(700*fade*(math.sin(2*math.pi*220*t)+.25*math.sin(2*math.pi*330*t)));w.writeframes(struct.pack("<h",max(-32767,min(32767,v))))

def build_video(r,language="en"):
    work=Path(tempfile.mkdtemp(prefix="fgv_"));sd=work/"scenes";sd.mkdir();imgs=scenes(r);dur=[6,8,9,7,8,12,7];paths=[]
    for i,im in enumerate(imgs):
        p=sd/f"{i:02d}.png";im.save(p);paths.append(p)
    concat=work/"concat.txt"
    with concat.open("w") as f:
        for p,d in zip(paths,dur): f.write(f"file '{p.as_posix()}'\nduration {d}\n")
        f.write(f"file '{paths[-1].as_posix()}'\n")
    ff=imageio_ffmpeg.get_ffmpeg_exe();silent=work/"silent.mp4"
    subprocess.run([ff,"-y","-f","concat","-safe","0","-i",str(concat),"-vf",f"scale={W}:{H},format=yuv420p","-r",str(FPS),"-c:v","libx264","-crf","21",str(silent)],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    audio=work/"bg.wav";make_bg_audio(audio,sum(dur));mp3=work/"voice.mp3"
    script=(f"FarmGuard AI weekly report for {r.get('crop','Rice')}. Today's rain probability is {round(r['weather']['daily']['precipitation_probability_max'][0])} percent. "
            f"The crop health analysis reports {r['prediction']['disease']} with {r['prediction']['confidence']} percent confidence, with an overall risk level of {r['disease_risk']['level']}. "
            f"The current water recommendation is {r['irrigation'][0]['action']}. The current market estimate is rupees {r['market']['current']} per quintal, with a modeled range of {r['market']['expected_low']} to {r['market']['expected_high']}. "
            f"The seven day plan starts with {r['plan'][0]['action']}. This report is decision support and should be reassessed as new observations and forecasts arrive.")
    try:
        if gTTS and language=="en":
            try:
                gTTS(text=script, lang="en", slow=False).save(str(mp3))
                audio = mp3
            except Exception:
                audio = bg
    except Exception:
        audio = bg
    out=OUT/f"farmguard_report_{datetime.now():%Y%m%d_%H%M%S}.mp4"
    subprocess.run([ff,"-y","-i",str(silent),"-i",str(audio),"-map","0:v:0","-map","1:a:0","-c:v","copy","-c:a","aac","-b:a","128k","-shortest",str(out)],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    return out
