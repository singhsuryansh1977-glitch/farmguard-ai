import os, json, math, sqlite3, tempfile, hashlib, hmac, secrets, re
from datetime import date, datetime, timedelta
from pathlib import Path

import requests
from fastapi import FastAPI, UploadFile, File, Form, Request, Response
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from .video_report import build_video

try:
    import psycopg
    from psycopg.rows import dict_row
except ImportError:
    psycopg = None
    dict_row = None

try:
    import boto3
except ImportError:
    boto3 = None


def safe_float(value, default=0.0):
    try:
        if value is None or value == "":
            return default
        return float(value)
    except (TypeError, ValueError):
        return default

def clamp(value, low=0.0, high=100.0):
    return max(low, min(high, value))

def api_error(message, status=400):
    return JSONResponse(status_code=status, content={"detail": message})

def normalize_email(value: str) -> str:
    return (value or "").strip().lower()

def valid_email(value: str) -> bool:
    return bool(re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", value or ""))

def hash_password(password: str, salt_hex: str | None = None) -> tuple[str, str]:
    salt = bytes.fromhex(salt_hex) if salt_hex else secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 210_000)
    return digest.hex(), salt.hex()

def verify_password(password: str, stored_hash: str, salt_hex: str) -> bool:
    computed, _ = hash_password(password, salt_hex)
    return hmac.compare_digest(computed, stored_hash)

def create_session(user_id: int, days: int = 7) -> str:
    token = secrets.token_urlsafe(48)
    created = datetime.now()
    expires = created + timedelta(days=days)
    con = db()
    con.execute("INSERT INTO sessions(token,user_id,created_at,expires_at) VALUES(?,?,?,?)",
                (token, user_id, created.isoformat(), expires.isoformat()))
    con.commit(); con.close()
    return token

def get_current_user(request):
    token = request.cookies.get("farmguard_session")
    if not token:
        return None
    con = db()
    row = con.execute("""
        SELECT u.id,u.name,u.email,s.expires_at
        FROM sessions s JOIN users u ON u.id=s.user_id
        WHERE s.token=?
    """,(token,)).fetchone()
    if not row:
        con.close(); return None
    try:
        expires = datetime.fromisoformat(row["expires_at"])
        if expires <= datetime.now():
            con.execute("DELETE FROM sessions WHERE token=?", (token,))
            con.commit(); con.close()
            return None
    except Exception:
        con.close(); return None
    con.close()
    return dict(row)

def require_user(request):
    user = get_current_user(request)
    if not user:
        return None
    return user

BASE = Path(__file__).resolve().parent.parent
MODEL_DIR = BASE / "models"
DB_PATH = BASE / "farmguard.db"
MODEL_PATH = MODEL_DIR / "rice_disease_resnet50.onnx"
MODEL_URL = "https://huggingface.co/nihal4/rice-disease-model/resolve/main/rice_disease_resnet50.onnx?download=true"

S3_BUCKET = os.getenv("S3_BUCKET", "").strip()
S3_REGION = os.getenv("S3_REGION", "us-east-1").strip()
S3_ENDPOINT_URL = os.getenv("S3_ENDPOINT_URL", "").strip() or None
S3_PUBLIC_BASE_URL = os.getenv("S3_PUBLIC_BASE_URL", "").strip().rstrip("/")
S3_ACCESS_KEY_ID = os.getenv("S3_ACCESS_KEY_ID", "").strip()
S3_SECRET_ACCESS_KEY = os.getenv("S3_SECRET_ACCESS_KEY", "").strip()
CLOUD_STORAGE_ENABLED = bool(S3_BUCKET and S3_ACCESS_KEY_ID and S3_SECRET_ACCESS_KEY and boto3)

def using_postgres():
    return bool(os.getenv("DATABASE_URL", "").strip())

def s3_client():
    if not CLOUD_STORAGE_ENABLED:
        return None
    return boto3.client("s3", region_name=S3_REGION, endpoint_url=S3_ENDPOINT_URL, aws_access_key_id=S3_ACCESS_KEY_ID, aws_secret_access_key=S3_SECRET_ACCESS_KEY)

def upload_file_to_cloud(path: Path, key: str, content_type: str):
    client = s3_client()
    if client is None:
        return None
    client.upload_file(str(path), S3_BUCKET, key, ExtraArgs={"ContentType": content_type})
    if S3_PUBLIC_BASE_URL:
        return f"{S3_PUBLIC_BASE_URL}/{key}"
    if S3_ENDPOINT_URL:
        return f"{S3_ENDPOINT_URL.rstrip('/')}/{S3_BUCKET}/{key}"
    return f"https://{S3_BUCKET}.s3.{S3_REGION}.amazonaws.com/{key}"

CROP_PROFILES = {
    "Rice": {"days":120,"water_need":"High","diseases":["Bacterial Leaf Blight","Brown Spot","Leaf Blast","Tungro"],"model":"rice","base_price":2250},
    "Wheat": {"days":120,"water_need":"Medium","diseases":["Leaf Rust","Stripe Rust","Powdery Mildew","Loose Smut"],"model":None,"base_price":2650},
    "Maize": {"days":100,"water_need":"Medium","diseases":["Fall Armyworm","Maydis Leaf Blight","Rust","Stalk Rot"],"model":None,"base_price":2300},
    "Cotton": {"days":170,"water_need":"Medium","diseases":["Bacterial Blight","Fusarium Wilt","Verticillium Wilt","Alternaria Leaf Spot"],"model":None,"base_price":7200},
    "Tomato": {"days":90,"water_need":"Medium-High","diseases":["Early Blight","Late Blight","Bacterial Spot","Leaf Mold"],"model":None,"base_price":2400},
    "Potato": {"days":100,"water_need":"Medium","diseases":["Late Blight","Early Blight","Black Scurf","Bacterial Wilt"],"model":None,"base_price":1800},
    "Soybean": {"days":100,"water_need":"Medium","diseases":["Rust","Yellow Mosaic Virus","Bacterial Pustule","Charcoal Rot"],"model":None,"base_price":4700},
    "Sugarcane": {"days":330,"water_need":"High","diseases":["Red Rot","Smut","Wilt","Leaf Scald"],"model":None,"base_price":360}
}
CLASS_NAMES = CROP_PROFILES["Rice"]["diseases"]

app = FastAPI(title="FarmGuard AI Advanced")
STATIC_DIR = BASE / "app" / "static"
GENERATED_DIR = BASE / "generated_videos"
GENERATED_DIR.mkdir(parents=True, exist_ok=True)
app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")
app.mount("/generated", StaticFiles(directory=str(GENERATED_DIR)), name="generated")

def sql(con, query, params=()):
    if using_postgres():
        query = query.replace("?", "%s")
    return con.execute(query, params)

def db():
    if using_postgres():
        if psycopg is None:
            raise RuntimeError("PostgreSQL support is missing. Install psycopg[binary].")
        return psycopg.connect(os.environ["DATABASE_URL"], row_factory=dict_row)
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con

def init_db():
    con = db()
    if using_postgres():
        statements = [
            "CREATE TABLE IF NOT EXISTS users(id BIGSERIAL PRIMARY KEY,name TEXT NOT NULL,email TEXT NOT NULL UNIQUE,password_hash TEXT NOT NULL,password_salt TEXT NOT NULL,created_at TEXT NOT NULL)",
            "CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY,user_id BIGINT NOT NULL,created_at TEXT NOT NULL,expires_at TEXT NOT NULL)",
            "CREATE TABLE IF NOT EXISTS farms(id BIGSERIAL PRIMARY KEY,user_id BIGINT,name TEXT,crop TEXT,variety TEXT,lat DOUBLE PRECISION,lon DOUBLE PRECISION,crop_age INTEGER,harvest_readiness DOUBLE PRECISION,field_water DOUBLE PRECISION,irrigation_last TEXT,last_inspection TEXT,fertilizer_last TEXT,notes TEXT,updated_at TEXT)",
            "CREATE TABLE IF NOT EXISTS activities(id BIGSERIAL PRIMARY KEY,user_id BIGINT,activity_date TEXT,activity TEXT,notes TEXT)"
        ]
        for statement in statements:
            sql(con, statement)
        con.commit(); con.close(); return
    sql(con, """CREATE TABLE IF NOT EXISTS farms(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,name TEXT,crop TEXT,variety TEXT,lat REAL,lon REAL,crop_age INTEGER,harvest_readiness REAL,field_water REAL,irrigation_last TEXT,last_inspection TEXT,fertilizer_last TEXT,notes TEXT,updated_at TEXT)""")
    sql(con, """CREATE TABLE IF NOT EXISTS activities(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,activity_date TEXT,activity TEXT,notes TEXT)""")
    sql(con, """CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,email TEXT NOT NULL UNIQUE,password_hash TEXT NOT NULL,password_salt TEXT NOT NULL,created_at TEXT NOT NULL)""")
    sql(con, """CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY,user_id INTEGER NOT NULL,created_at TEXT NOT NULL,expires_at TEXT NOT NULL)""")
    con.commit(); con.close()

init_db()

def get_weather(lat, lon):
    try:
        lat = clamp(safe_float(lat), -90, 90)
        lon = clamp(safe_float(lon), -180, 180)
        url = "https://api.open-meteo.com/v1/forecast"
        params = {
            "latitude": lat, "longitude": lon, "timezone": "auto",
            "forecast_days": 7,
            "current": "temperature_2m,relative_humidity_2m,precipitation,rain,weather_code,wind_speed_10m",
            "daily": ",".join([
                "temperature_2m_max","temperature_2m_min","precipitation_sum",
                "precipitation_probability_max","et0_fao_evapotranspiration",
                "wind_speed_10m_max","weather_code"
            ])
        }
        r = requests.get(url, params=params, timeout=15)
        r.raise_for_status()
        data = r.json()
        if "current" not in data or "daily" not in data:
            raise ValueError("Weather service returned incomplete data.")
        return data
    except Exception as exc:
        today = datetime.now().date()
        days = [(today + timedelta(days=i)).isoformat() for i in range(7)]
        return {
            "source": "FALLBACK",
            "warning": f"Live weather unavailable: {exc}",
            "current": {
                "temperature_2m": 28.0, "relative_humidity_2m": 70.0,
                "precipitation": 0.0, "rain": 0.0, "weather_code": 0,
                "wind_speed_10m": 5.0
            },
            "daily": {
                "time": days,
                "temperature_2m_max": [31.0]*7,
                "temperature_2m_min": [23.0]*7,
                "precipitation_sum": [0.0]*7,
                "precipitation_probability_max": [30.0]*7,
                "et0_fao_evapotranspiration": [4.0]*7,
                "wind_speed_10m_max": [10.0]*7,
                "weather_code": [0]*7
            }
        }

def download_model():
    MODEL_DIR.mkdir(exist_ok=True)
    if MODEL_PATH.exists() and MODEL_PATH.stat().st_size > 10_000_000:
        return MODEL_PATH
    with requests.get(MODEL_URL, stream=True, timeout=120) as r:
        r.raise_for_status()
        with open(MODEL_PATH, "wb") as f:
            for chunk in r.iter_content(chunk_size=1024*1024):
                if chunk: f.write(chunk)
    return MODEL_PATH

def predict_disease(image_bytes, crop="Rice"):
    try:
        profile = CROP_PROFILES.get(crop, CROP_PROFILES["Rice"])
        if profile.get("model") != "rice":
            return {"disease":"Crop image model not connected","confidence":0,"probabilities":{},
                    "model_status":"not_available",
                    "error":f"The {crop} image model is not connected yet. Weather, irrigation and market analysis still work."}

        import numpy as np
        from PIL import Image
        import onnxruntime as ort
        with tempfile.NamedTemporaryFile(suffix=".jpg", delete=False) as tmp:
            tmp.write(image_bytes); tmp.flush()
            img = Image.open(tmp.name).convert("RGB").resize((224,224))
        arr = np.asarray(img, dtype=np.float32) / 255.0
        arr = (arr - np.array([0.485,0.456,0.406], dtype=np.float32)) / np.array([0.229,0.224,0.225], dtype=np.float32)
        x = arr.transpose(2,0,1)[None,:].astype(np.float32)
        model = download_model()
        session = ort.InferenceSession(str(model), providers=["CPUExecutionProvider"])
        inp = session.get_inputs()[0].name
        out = session.run(None, {inp: x})[0][0]
        out = np.exp(out - np.max(out)); probs = out / out.sum()
        idx = int(np.argmax(probs))
        return {"disease": CLASS_NAMES[idx], "confidence": round(float(probs[idx])*100,1),
                "probabilities": {CLASS_NAMES[i]: round(float(probs[i])*100,1) for i in range(4)},
                "model_status":"ready"}
    except Exception as e:
        return {"disease":"Model unavailable","confidence":0,"probabilities":{},
                "model_status":"error","error":str(e)}

def disease_risk(weather, prediction):
    cur = weather.get("current", {})
    humidity = safe_float(cur.get("relative_humidity_2m"))
    rain = safe_float((weather.get("daily",{}).get("precipitation_probability_max") or [0])[0])
    disease = prediction.get("disease","")
    conf = safe_float(prediction.get("confidence"))
    # Conservative risk score: a disease image prediction is only one signal.
    risk = 15.0
    if humidity >= 85: risk += 25
    elif humidity >= 75: risk += 15
    elif humidity >= 65: risk += 8
    if rain >= 80: risk += 20
    elif rain >= 60: risk += 12
    elif rain >= 40: risk += 6
    if disease not in ("","Model unavailable","Crop image model not connected"):
        risk += min(40.0, conf * 0.40)
    risk = int(round(clamp(risk)))
    level = "HIGH" if risk >= 70 else "MODERATE" if risk >= 45 else "LOW"
    return risk, level

def irrigation_plan(weather, crop_age, field_water):
    d = weather["daily"]
    actions=[]
    for i in range(7):
        rain = float(d["precipitation_probability_max"][i] or 0)
        rain_mm = float(d["precipitation_sum"][i] or 0)
        et0 = float(d.get("et0_fao_evapotranspiration",[0]*7)[i] or 0)
        if rain >= 70 or rain_mm >= 8:
            act = "NO FIELD IRRIGATION"
            reason = f"Rain chance {rain:.0f}% / forecast rain {rain_mm:.1f} mm."
        elif field_water >= 70:
            act = "CHECK FIELD WATER"
            reason = "Field water level is already high."
        elif rain < 35 and et0 >= 4:
            act = "IRRIGATE IF SOIL IS DRY"
            reason = f"Low rain chance and ET₀ about {et0:.1f} mm."
        else:
            act = "FIELD MONITORING"
            reason = "Check soil/standing-water condition before pumping."
        actions.append({"day":i+1,"date":d["time"][i],"action":act,"reason":reason,
                        "rain_probability":rain,"rain_mm":rain_mm,"et0":et0})
    return actions

def market_data(crop="Rice", state=""):
    # Live mandi integration can be enabled with DATA_GOV_API_KEY.
    # Without a key, use clearly-labelled demo values so the app remains runnable.
    api_key = os.getenv("DATA_GOV_API_KEY","").strip()
    resource = os.getenv("DATA_GOV_RESOURCE_ID","").strip()
    if api_key and resource:
        try:
            url=f"https://api.data.gov.in/resource/{resource}"
            params={"api-key":api_key,"format":"json","limit":50}
            r=requests.get(url,params=params,timeout=15); r.raise_for_status()
            records=r.json().get("records",[])
            prices=[]
            for x in records:
                for k in ("modal_price","Modal_Price","modalprice"):
                    if x.get(k) not in (None,""):
                        try: prices.append(float(str(x[k]).replace(",",""))); break
                        except: pass
            if prices:
                cur=sum(prices)/len(prices)
                return {"source":"data.gov.in","live":True,"current":round(cur,0),
                        "expected_low":round(cur*1.02,0),"expected_high":round(cur*1.06,0),
                        "trend":"UP","note":"Live records retrieved from configured data.gov.in resource."}
        except Exception as e:
            pass
    base = CROP_PROFILES.get(crop, CROP_PROFILES["Rice"])["base_price"]
    return {"source":"DEMO FALLBACK","live":False,"current":base,
            "expected_low":round(base*1.02),"expected_high":round(base*1.06),"trend":"UP",
            "note":f"Demo estimate for {crop}. Configure DATA_GOV_API_KEY + DATA_GOV_RESOURCE_ID for live mandi data."}

def treatment_for(disease, crop="Rice"):
    advice = {
        "Bacterial Leaf Blight":"Scout affected patches, avoid excess nitrogen and follow local agricultural extension advice for approved controls.",
        "Brown Spot":"Maintain balanced nutrition, avoid prolonged leaf wetness and follow local extension advice.",
        "Leaf Blast":"Monitor nearby plants, avoid excess nitrogen and follow local extension guidance.",
        "Tungro":"Monitor leafhopper pressure and affected clumps; follow local extension guidance.",
        "Leaf Rust":"Scout regularly and follow locally approved rust-management guidance.",
        "Stripe Rust":"Monitor cool/humid periods closely and seek local extension guidance if symptoms appear.",
        "Powdery Mildew":"Improve canopy airflow and follow local extension guidance.",
        "Fall Armyworm":"Scout whorls and field edges; use integrated pest management and locally approved controls when thresholds are exceeded.",
        "Maydis Leaf Blight":"Scout lower leaves and follow local extension guidance.",
        "Rust":"Scout foliage regularly and follow locally approved rust-management guidance.",
        "Bacterial Blight":"Use sanitation and locally recommended disease-management practices.",
        "Fusarium Wilt":"Remove affected plants where advised and maintain field sanitation.",
        "Verticillium Wilt":"Use sanitation and crop-rotation practices recommended locally.",
        "Alternaria Leaf Spot":"Improve airflow and avoid prolonged leaf wetness.",
        "Early Blight":"Scout foliage and follow local extension guidance.",
        "Late Blight":"Scout after rainy/cool periods and seek rapid local advice if symptoms appear.",
        "Bacterial Spot":"Avoid working wet foliage and maintain sanitation.",
        "Leaf Mold":"Improve ventilation and avoid prolonged leaf wetness.",
        "Black Scurf":"Use clean planting material and sanitation/rotation practices.",
        "Bacterial Wilt":"Use clean planting material and sanitation; remove affected plants where advised.",
        "Yellow Mosaic Virus":"Monitor vectors and follow local extension guidance.",
        "Bacterial Pustule":"Scout foliage and use locally recommended sanitation practices.",
        "Charcoal Rot":"Avoid severe moisture stress and improve soil health.",
        "Red Rot":"Use clean planting material and rogue affected clumps where advised.",
        "Smut":"Use clean planting material and follow local sanitation guidance.",
        "Wilt":"Use clean planting material and crop rotation where advised.",
        "Leaf Scald":"Use clean planting material and field sanitation.",
        "Crop image model not connected":"The crop-specific image model is not connected yet. The weather/risk engine remains active; use field scouting and local extension advice."
    }
    return advice.get(disease, f"Monitor the {crop} field and seek local agricultural extension advice before applying pesticides.")

def build_plan(weather, disease, risk, irrigation, crop_age, harvest):
    plan=[]
    for x in irrigation:
        act=x["action"]; why=x["reason"]
        if risk>=70 and x["day"] in (1,2,3):
            act="DISEASE SCOUTING + " + act
            why += " Disease risk is high; inspect lower leaves and nearby plants."
        if harvest>=80 and x["day"]>=4:
            act="HARVEST READINESS CHECK"
            why="Crop is nearing harvest readiness; inspect grain maturity and local market."
        plan.append({"day":x["day"],"date":x["date"],"action":act,"reason":why})
    return plan

@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    return (BASE/"app"/"static"/"index.html").read_text(encoding="utf-8")


@app.post("/api/signup")
async def signup(payload: dict, response: Response):
    name = (payload.get("name") or "").strip()
    email = normalize_email(payload.get("email"))
    password = payload.get("password") or ""
    if len(name) < 2:
        return api_error("Please enter your full name.", 422)
    if not valid_email(email):
        return api_error("Please enter a valid email address.", 422)
    if len(password) < 8:
        return api_error("Password must be at least 8 characters.", 422)
    if not re.search(r"[A-Za-z]", password) or not re.search(r"\d", password):
        return api_error("Password must contain at least one letter and one number.", 422)
    con = db()
    if sql(con, "SELECT id FROM users WHERE email=?", (email,)).fetchone():
        con.close()
        return api_error("An account with this email already exists. Try logging in.", 409)
    pw_hash, salt = hash_password(password)
    insert_sql = (
        "INSERT INTO users(name,email,password_hash,password_salt,created_at) VALUES(%s,%s,%s,%s,%s) RETURNING id"
        if using_postgres() else
        "INSERT INTO users(name,email,password_hash,password_salt,created_at) VALUES(?,?,?,?,?)"
    )
    cur = sql(con, insert_sql, (name,email,pw_hash,salt,datetime.now().isoformat()))
    user_id = cur.fetchone()["id"] if using_postgres() else cur.lastrowid
    con.commit(); con.close()
    token = create_session(user_id)
    response.set_cookie("farmguard_session", token, httponly=True, samesite="lax", max_age=7*24*3600)
    return {"ok": True, "user": {"name": name, "email": email}}

@app.post("/api/login")
async def login(payload: dict, response: Response):
    email = normalize_email(payload.get("email"))
    password = payload.get("password") or ""
    if not valid_email(email):
        return api_error("Please enter a valid email address.", 422)
    if not password:
        return api_error("Please enter your password.", 422)
    con = db()
    row = sql(con, "SELECT * FROM users WHERE email=?", (email,)).fetchone()
    con.close()
    if not row or not verify_password(password, row["password_hash"], row["password_salt"]):
        return api_error("Email or password is incorrect.", 401)
    token = create_session(row["id"])
    response.set_cookie("farmguard_session", token, httponly=True, samesite="lax", max_age=7*24*3600)
    return {"ok": True, "user": {"name": row["name"], "email": row["email"]}}

@app.post("/api/logout")
async def logout(request: Request, response: Response):
    token = request.cookies.get("farmguard_session")
    if token:
        con = db(); sql(con, "DELETE FROM sessions WHERE token=?", (token,)); con.commit(); con.close()
    response.delete_cookie("farmguard_session")
    return {"ok": True}

@app.get("/api/me")
def me(request: Request):
    user = get_current_user(request)
    if not user:
        return JSONResponse(status_code=401, content={"detail":"Not logged in"})
    return {"ok": True, "user": {"name": user["name"], "email": user["email"]}}

@app.post("/api/analyze")
async def analyze(
    request: Request,
    crop: str = Form("Rice"), lat: float = Form(...), lon: float = Form(...),
    crop_age: int = Form(60), harvest: float = Form(65), field_water: float = Form(40),
    irrigation_last: str = Form(""), fertilizer_last: str = Form(""),
    last_inspection: str = Form(""), notes: str = Form(""),
    image: UploadFile | None = File(None)
):
    user = require_user(request)
    if not user:
        return api_error("Please log in to analyze your farm.", 401)
    weather=get_weather(lat,lon)
    pred={"disease":"Model unavailable","confidence":0,"probabilities":{},"model_status":"not_run"}
    if image and image.filename:
        content_type = (image.content_type or "").lower()
        if not content_type.startswith("image/"):
            return api_error("Please upload an image file such as JPG, PNG or WEBP.")
        pred = predict_disease(await image.read(), crop)
    risk, level=disease_risk(weather,pred)
    irrigation=irrigation_plan(weather,crop_age,field_water)
    market=market_data(crop)
    plan=build_plan(weather,pred["disease"],risk,irrigation,crop_age,harvest)
    con=db()
    sql(con, "INSERT INTO farms(user_id,name,crop,variety,lat,lon,crop_age,harvest_readiness,field_water,irrigation_last,last_inspection,fertilizer_last,notes,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (user["id"],"My Farm",crop,"",lat,lon,crop_age,harvest,field_water,irrigation_last,last_inspection,fertilizer_last,notes,datetime.now().isoformat()))
    con.commit(); con.close()
    return {
        "crop":crop,"weather":weather,"prediction":pred,
        "disease_risk":{"score":risk,"level":level,"advice":treatment_for(pred["disease"], crop),
                         "crop_profile":CROP_PROFILES.get(crop, {})},
        "irrigation":irrigation,"market":market,"plan":plan,
        "farm_activity":{"field_water":field_water,"irrigation_last":irrigation_last,
                         "fertilizer_last":fertilizer_last,"last_inspection":last_inspection}
    }

@app.get("/api/crops")
def crops():
    return CROP_PROFILES

@app.post("/api/report-video")
async def report_video(payload: dict):
    try:
        path=build_video(payload,payload.get("language","en"))
        cloud_url = upload_file_to_cloud(path, f"reports/{path.name}", "video/mp4")
        if cloud_url:
            try: path.unlink()
            except OSError: pass
            return {"video_url":cloud_url,"filename":path.name,"storage":"cloud"}
        return {"video_url":f"/generated/{path.name}","filename":path.name,"storage":"local"}
    except Exception as e:
        return JSONResponse(status_code=500,content={"detail":str(e)})

@app.get("/api/health")
def health():
    return {"status":"ok","app":"FarmGuard AI Advanced","database":"postgresql" if using_postgres() else "sqlite","object_storage":"s3" if CLOUD_STORAGE_ENABLED else "local"}

@app.get("/api/model-status")
def model_status():
    return {"downloaded": MODEL_PATH.exists(),
            "size_mb": round(MODEL_PATH.stat().st_size/1024/1024,1) if MODEL_PATH.exists() else 0}