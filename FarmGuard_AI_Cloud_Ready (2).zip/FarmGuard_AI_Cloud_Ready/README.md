# FarmGuard AI — Multi-Crop Advanced MVP

Supported crops:
- Rice
- Wheat
- Maize
- Cotton
- Tomato
- Potato
- Soybean
- Sugarcane

The application now uses a crop-profile architecture. Each crop has its own disease/pest list, water-need category, crop duration and market baseline.

### Important AI limitation
Rice has the connected rice-leaf ONNX image model.

For the other crops, the app deliberately does **not** pretend that the rice model can diagnose them. They currently use crop-specific weather/risk intelligence, irrigation rules and market logic.

The next step is to add validated image models for each crop (or one properly trained multi-crop model).

### Run
```powershell
python -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
.venv\Scripts\python.exe -m uvicorn app.main:app --host 127.0.0.1 --port 8080
```
Open http://127.0.0.1:8080

### Market
Demo values are clearly labelled. For live data.gov.in integration:
```powershell
$env:DATA_GOV_API_KEY="YOUR_KEY"
$env:DATA_GOV_RESOURCE_ID="YOUR_RESOURCE_ID"
```
Restart the server.

### PWA / deployment
The app is PWA-ready and includes an install button. For browser installation, serve it from HTTPS (localhost is also supported during development).

A `render.yaml` file is included for straightforward FastAPI deployment on Render. After deployment, open the HTTPS site in Chrome/Edge on a supported device; the **Install App** button can then trigger the browser installation prompt. On iPhone/iPad Safari, use **Share → Add to Home Screen**.

Note: this project stores SQLite data and generated videos on the local filesystem. Many cloud web hosts use ephemeral storage, so production deployment should move persistent data/video storage to a database/object-storage service if you need data to survive redeploys.

### Roadmap
1. Add validated image datasets/models per crop.
2. Add growth-stage models.
3. Add state/district/mandi-specific live market resources.
4. Add Hindi/regional-language and voice support.
5. Add alerts, farmer accounts and mobile/PWA deployment.

## AI Farm Report Video
After analysis, click Generate AI Farm Report to create a polished 7-scene MP4 with visuals, conclusions, action plan and optional online narration. The app falls back to subtle audio if TTS is unavailable.


## Reliability / accuracy notes

- Weather automatically falls back to demo values if the live weather request fails; the UI labels this.
- Market figures are demo values until a verified data.gov.in resource is configured; the UI labels this.
- Only Rice currently has a connected image model. Other crops use crop-specific risk rules and do not fake an image diagnosis.
- AI disease predictions are decision support, not a medical/laboratory-style certainty. Validate on local field images before making production claims.
- Pesticide/treatment guidance is intentionally high-level; farmers should follow local agricultural extension labels and regulations.

## Troubleshooting

If the app opens but the analysis fails:
1. Keep the server terminal open.
2. Read the last error line in the terminal.
3. Check that the selected image is JPG/PNG/WEBP and under 8 MB.
4. If the model is downloading, wait for it to finish before retrying.


## Cloud storage

The application now supports cloud persistence. When `DATABASE_URL` is present, user accounts, sessions, farm records, and activity data use PostgreSQL instead of local SQLite. Generated report videos can be uploaded to any S3-compatible object store when these variables are configured: `S3_BUCKET`, `S3_REGION`, `S3_ENDPOINT_URL` (optional for AWS S3), `S3_PUBLIC_BASE_URL` (optional), `S3_ACCESS_KEY_ID`, and `S3_SECRET_ACCESS_KEY`.

For Render, `render.yaml` provisions a managed Postgres database and wires its connection string into the web service automatically. Render services have ephemeral filesystems, so object storage is recommended for generated videos and uploaded files. Render documents that free Postgres expires after 30 days; use a paid database for persistent production data.
